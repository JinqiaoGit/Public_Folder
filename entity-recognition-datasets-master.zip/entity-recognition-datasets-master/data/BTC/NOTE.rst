The CONLL-formatted files from the BTC corpus were downloaded from
https://github.com/GateNLP/broad_twitter_corpus in August, 2018.

For more information, see the README.md, and the following paper:

Broad Twitter Corpus: A Diverse Named Entity Recognition Resource.
Leon Derczynski, Kalina Bontcheva, and Ian Roberts. Proceedings of COLING,
pages 1169-1179 2016.

