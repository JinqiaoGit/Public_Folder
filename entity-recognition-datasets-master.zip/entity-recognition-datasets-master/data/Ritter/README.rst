Ritter Twitter Dataset
======================

Ritter's Twitter corpus is the same as the training portion of WNUT16 (though
with sentences in a different order).

The training/test/dev split here (80%/10%/10%) was used in the paper of
Yang et al, "Transfer Learning for Sequence Tagging with Hierarchical
Recurrent Networks".

This data was downloaded in January 2018 from:

http://kimi.ml.cmu.edu/transfer/data.tar.gz
