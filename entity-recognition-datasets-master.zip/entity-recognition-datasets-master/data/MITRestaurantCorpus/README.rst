MIT Restaurant dataset
======================

This dataset was downloaded on January 2018 from

https://groups.csail.mit.edu/sls/downloads/restaurant/

See also:
https://groups.csail.mit.edu/sls/downloads/
