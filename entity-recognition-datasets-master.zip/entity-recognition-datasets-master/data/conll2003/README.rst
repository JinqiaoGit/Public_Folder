NOTE
----

This is the original CONLL dataset, except for a couple
corrections listed below:

* Fixed tokenization of the following form:
  [X][.] -> [X.], and associated sentence tokenization errors, for:

    - Rep, Sen
    - U.S
